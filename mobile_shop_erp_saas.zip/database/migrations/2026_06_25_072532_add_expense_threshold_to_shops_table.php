<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('shops', function (Blueprint $table) {
            // 0 = no threshold (everything auto-approves)
            $table->decimal('expense_approval_threshold', 12, 2)
                ->default(0)
                ->after('books_locked_through');
        });
    }

    public function down(): void
    {
        Schema::table('shops', function (Blueprint $table) {
            $table->dropColumn('expense_approval_threshold');
        });
    }
};