<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    // ..._add_password_changed_at_to_users_table.php
public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->timestamp('password_changed_at')->nullable()->after('password');
    });
}

public function down(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->dropColumn('password_changed_at');
    });
}
};
