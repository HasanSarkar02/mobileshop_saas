<?php

namespace App\Livewire\Products;

use App\Enums\ProductTrackingType;
use App\Models\Category;
use App\Models\Product;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('components.layouts.app')]
#[Title('Products')]
class ProductList extends Component
{
    use WithPagination;

    #[Url(as: 'q')]
    public string $search = '';

    #[Url]
    public string $trackingType = '';

    #[Url]
    public int $categoryId = 0;

    public bool   $showAddBrand    = false;
    public bool   $showAddCategory = false;
    public string $newBrandName    = '';
    public string $newCategoryName = '';

    public function updatingSearch(): void { $this->resetPage(); }
    public function updatingTrackingType(): void { $this->resetPage(); }
    public function updatingCategoryId(): void { $this->resetPage(); }

    public function toggleActive(int $productId): void
    {
        $product = Product::findOrFail($productId);
        $product->update(['is_active' => ! $product->is_active]);
        $this->dispatch('notify', type: 'success', message: 'Product status updated.');
    }

    public function render()
    {
        $products = Product::with(['brand', 'category', 'variants'])
            ->when($this->search, fn($q) =>
                $q->where('name', 'like', "%{$this->search}%")
            )
            ->when($this->trackingType, fn($q) =>
                $q->where('tracking_type', $this->trackingType)
            )
            ->when($this->categoryId, fn($q) =>
                $q->where('category_id', $this->categoryId)
            )
            ->withCount(['variants as active_variant_count' => fn($q) => $q->where('is_active', true)])
            ->latest()
            ->paginate(20);

        $categories = Category::orderBy('name')->get();

        return view('livewire.products.product-list', compact('products', 'categories'));
    }

    public function addBrand(): void
    {
        $this->validate(['newBrandName' => 'required|string|max:100']);

        \App\Models\Brand::firstOrCreate(
            ['name' => $this->newBrandName, 'shop_id' => \Illuminate\Support\Facades\Auth::user()->shop_id],
            ['is_active' => true]
        );

        unset($this->brands);
        $this->showAddBrand  = false;
        $this->newBrandName  = '';
        $this->dispatch('notify', ['type' => 'success', 'message' => 'Brand added.']);
    }

    public function addCategory(): void
    {
        $this->validate(['newCategoryName' => 'required|string|max:100']);

        \App\Models\Category::firstOrCreate(
            ['name' => $this->newCategoryName, 'shop_id' => \Illuminate\Support\Facades\Auth::user()->shop_id],
            ['is_active' => true]
        );

        unset($this->categories);
        $this->showAddCategory  = false;
        $this->newCategoryName  = '';
        $this->dispatch('notify', ['type' => 'success', 'message' => 'Category added.']);
    }
}