<?php

namespace App\Providers;

use App\Actions\Fortify\ResetUserPassword;
use App\Actions\Fortify\UpdateUserPassword;
use App\Enums\ShopStatus;
use App\Enums\UserType;
use App\Models\User;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\ValidationException;
use Laravel\Fortify\Fortify;

class FortifyServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Fortify::resetUserPasswordsUsing(ResetUserPassword::class);
        Fortify::updateUserPasswordsUsing(UpdateUserPassword::class);
        Fortify::loginView(fn () => view('auth.login'));
        Fortify::requestPasswordResetLinkView(fn () => view('auth.forgot-password'));
        Fortify::resetPasswordView(fn (Request $request) => view('auth.reset-password', ['request' => $request]));

        Fortify::authenticateUsing(function (Request $request) {
            $user = User::where('email', $request->email)->first();

            if (! $user || ! Hash::check($request->password, $user->password)) {
                return null;
            }

            // Super Admins authenticate only through /admin/login, never here.
            if ($user->user_type === UserType::SuperAdmin) {
                return null;
            }

            if (! $user->is_active) {
                throw ValidationException::withMessages([
                    Fortify::username() => 'This account has been deactivated. Please contact your shop owner.',
                ]);
            }

            if (! $user->has_system_access) {
                throw ValidationException::withMessages([
                    Fortify::username() => 'This account does not have system access.',
                ]);
            }

            $shop = $user->shop;

            if ($shop && (! $shop->is_active || in_array($shop->status, [ShopStatus::Suspended, ShopStatus::Expired], true))) {
                throw ValidationException::withMessages([
                    Fortify::username() => 'This shop account is currently suspended. Please contact support.',
                ]);
            }

            $user->forceFill(['last_login_at' => now()])->saveQuietly();

            return $user;
        });

        RateLimiter::for('login', function (Request $request) {
            $throttleKey = strtolower($request->input(Fortify::username())).'|'.$request->ip();

            return Limit::perMinute(5)->by($throttleKey);
        });

        // Fortify::requestPasswordResetLinkUsing(function (Request $request) {
        //     $user = User::where('email', $request->input(Fortify::email()))->first();

        //     if ($user?->isSuperAdmin()) {
        //         // Silently do nothing — caller sees the same "link sent" message
        //         // so they can't tell whether the email is a real admin account.
        //         return Password::RESET_LINK_SENT;
        //     }

        //     return Password::broker()->sendResetLink(
        //         $request->only(Fortify::email())
        //     );
        // });
    }
}